#include <iostream>
#include <ctime>
#include <vector>
#include <string>
using namespace std;

int kawasakiNinja = 3500, yamahaYZFR1 = 3800, suzukiGixxer = 3500, suzukiGSX = 3300, yamahaAerox = 2800, yamahaNMAX = 3000, hondaClick = 2500, hondaXR = 3000, bike = 2000;
int selection, age, contactNumber;
string completeAddress, emailAddress;

int motorAvaiOrNOT[] = {2, 2, 2, 2, 2, 2, 2, 2, 2};

struct RentalTransaction {
    string fullName;
    string motorBrand;
    int days;
    int totalPayment;
};


vector<RentalTransaction> rentalHistory;

void rentHistory() {

     time_t timetoday;
    time(&timetoday);

    system("CLS");
    int totalIncome = 0;
    cout << "History of Rentals\n";
    cout<<endl;

    for (const auto& transaction : rentalHistory) {

        cout << "\t\tName: " << transaction.fullName << endl;
        cout << "\t\tMotor Brand: " << transaction.motorBrand << endl;
        cout << "\t\tDays: " << transaction.days << endl;
        cout << "\t\tTotal Payment: " << transaction.totalPayment << endl;
        cout << "\t\tTime Rented: " << asctime(localtime(&timetoday)) << endl;
        totalIncome += transaction.totalPayment;
    cout<<"\t\t__________________________________________________________________________"<<endl;
    }
    cout<<endl;
    cout << "\t\tTotal Income: " << totalIncome << endl;

    cout<<endl;
    cout<<endl;

trac:
    cout<<"\t\t\t\tDo you want another transaction? [1] Yes [2] No   ";
    int antrac;cin>>antrac;
    if(antrac == 1)
    {
    cout<<".....\n";
    }
    else if(antrac == 2)
    {
    void exit(int Code);
    }
    else
    {
        cout<<"Invalid Input, Please do try again";
        goto trac;
    }
}


void displayMotor() {
    cout << "\t\tMotorcycles\n\n";
    cout << "\t[1] Kawasaki Ninja ZX-14 Green\t" << (motorAvaiOrNOT[0] > 0 ? "Available" : "Not Available") << " | Price: " << kawasakiNinja << " per Day" << endl;
    cout << "\t[2] Yamaha YZF-R1 Blue\t\t" << (motorAvaiOrNOT[1] > 0 ? "Available" : "Not Available") << " | Price: " << yamahaYZFR1 << " per Day" << endl;
    cout << "\t[3] Suzuki Gixxer SF GSX250R\t" << (motorAvaiOrNOT[2] > 0 ? "Available" : "Not Available") << " | Price: " << suzukiGixxer << " per Day" << endl;
    cout << "\t[4] Suzuki GSX-R600 Red\t\t" << (motorAvaiOrNOT[3] > 0 ? "Available" : "Not Available") << " | Price: " << suzukiGSX << " per Day" << endl;
    cout << "\t[5] Yamaha Aerox Yellow\t\t" << (motorAvaiOrNOT[4] > 0 ? "Available" : "Not Available") << " | Price: " << yamahaAerox << " per Day" << endl;
    cout << "\t[6] Yamaha NMAX White\t\t" << (motorAvaiOrNOT[5] > 0 ? "Available" : "Not Available") << " | Price: " << yamahaNMAX << " per Day" << endl;
    cout << "\t[7] Honda Click Red\t\t" << (motorAvaiOrNOT[6] > 0 ? "Available" : "Not Available") << " | Price: " << hondaClick << " per Day" << endl;
    cout << "\t[8] Honda XR 150\t\t\t" << (motorAvaiOrNOT[7] > 0 ? "Available" : "Not Available") << " | Price: " << hondaXR << " per Day" << endl;
    cout << "\t[9] Bike Cycling\t\t\t" << (motorAvaiOrNOT[8] > 0 ? "Available" : "Not Available") << " | Price: " << bike << " per Day" << endl;
}

void enterInformation(RentalTransaction &transaction) {



    cout << "\tEnter your Fullname[Last, First, Middle]: ";
    cin.ignore();
    getline(cin, transaction.fullName);
    cout << "\tEnter Age: ";
    cin >> age;
    cin.ignore();
    cout << "\tEnter Complete Address: ";
    getline(cin, completeAddress);
    cout << "\tEnter Contact Number: ";
    cin >> contactNumber;
    cout << "\tEmail Address: ";
    cin.ignore();
    getline(cin, emailAddress);
}



void proceedRent();

int motorAvailability(int motorChoice) {
    if (motorAvaiOrNOT[motorChoice - 1] > 0) {
        motorAvaiOrNOT[motorChoice - 1]--;
        return motorChoice;
    } else {
        cout << "Selected motorcycle is not available." << endl;
        proceedRent();
        return -1;
    }
}




void showMotor()
{
cout<<"\t\tMotorcycles\n";
            cout<<endl;
            cout<<"\t\tKawasaki Ninja ZX-14 Green\t"<<endl;
            cout<<"\t\tYamaha YZF-R1 Blue\t" <<endl;
            cout<<"\t\tSuzuki Gixxer SF GSX250R\t\t" <<endl;
            cout<<"\t\tSuzuki GSX-R600 Red"<<endl;
            cout<<"\t\tYamaha Aerox Yellow\t" <<endl;
            cout<<"\t\tYamaha NMAX White\t\t" <<endl;
            cout<<"\t\tHonda Click Red\t\t"<<endl;
            cout<<"\t\tHonda XR 150\t\t"<<endl;
            cout<<"\t\tBike Cycling\t\t"<<endl;
            cout<<endl;

        show:

            cout<<"\t\tDo you want rent? [1] Yes [2] No   ";
            int input;cin>>input;
                if(input == 1)
                {
                    proceedRent();
                }
                else if(input == 2)
                {
                    void exit(int Code);
                }
                else
                {
                    cout<<"Invalid, Please try again \n";
                    goto show;
                }

}

void mainSelection(){
    main:
        system("CLS");
        cout << "[1] Motorcycles\n";
        cout << "[2] Rent Motorcycle\n";
        cout << "[3] Transaction History\n";
        cout << "[4] Exit\n";
        cout << "Select an option: ";
        cin >> selection;

        switch (selection) {
            case 1:
                system("CLS");
                showMotor();
                break;
            case 2:
                proceedRent();
                break;
            case 3:
                rentHistory();
                break;
            case 4:
                void exit(int Code);
                break;
            default:
                cout << "Incorrect Input, Please try again." << endl;
                goto main;
                break;
        }

}

void termsAndConditions()
{
    cout<<endl;
    cout<<"\t\tThis Motorcycle Rental Terms and Agreement outlines the terms and conditions\n\t\tbetween Gilbert Motorcycle Rental  and the Renter. The rental period begins on\n\t\tthe Date and time of rent and ends on date and time. The Company agrees to \n\t\tprovide the Renter with specfied motorcycle for the duration of the rental period,\n\t\tincluding details such as brand, model, license plate number, engine capacity and color.\n\t\tThe Renter must meet eligibility requirements, including being at least [age] years\n\t\told and possessing a valid motorcycle license. A security deposit of [amount]\n\t\tis required at the time of rental to cover damages or losses. The Renter agrees to pay.\n\t\tthe agreed-upon rental fee, as well as any additional charges incurred during the rental period.\n\n\t\tDuring the rental period, the Renter agrees to use the motorcycle(s) solely for.\n\t\tpersonal transportation purposes and to comply with all applicable laws and regulations.\n\t\tProhibited activities include racing, reckless driving, off-road riding, and subleasing.\n\t\tThe Rental Company will provide the motorcycle(s) in good working condition and cover the costs\n\t\tof necessary repairs during the rental period. The Renter assumes responsibility\n\t\tfor accidents, injuries, or damages caused by their use of the motorcycle(s) and may \n\t\topt to purchase additional insurance coverage.\n\n\t\tThe Agreement may be terminated by the Rental Company for breach of contract or other\n\t\tjustifiable reasons. It is governed by the laws of [jurisdiction], with any disputes resolved\n\t\tthrough arbitration. By the agreement, both parties acknowledge understanding and\n\t\tagreement to abide by the terms and conditions outlined in this Agreement for the\n\t\tduration of the rental period.\n";
    cout<<endl;


}



void proceedRent() {

    time_t timetoday;
    time(&timetoday);

    system("CLS");
    cout << endl;
    cout << "\tChoose Motorcycle\n\n";
    displayMotor();

    int motorChoice;
    cin >> motorChoice;

    if (motorChoice < 1 || motorChoice > 9) {
        cout << "Invalid motorcycle number. Please try again." << endl;
        proceedRent();
        return;
    }

    int available = motorAvailability(motorChoice);
    if (available == -1) return;

    RentalTransaction transaction;
    switch (motorChoice) {
        case 1:
            transaction.motorBrand = "Kawasaki Ninja ZX-14 Green";
            transaction.totalPayment = kawasakiNinja;
            break;
        case 2:
            transaction.motorBrand = "Yamaha YZF-R1 Blue";
            transaction.totalPayment = yamahaYZFR1;
            break;
        case 3:
            transaction.motorBrand = "Suzuki Gixxer SF GSX250R";
            transaction.totalPayment = suzukiGixxer;
            break;
        case 4:
            transaction.motorBrand = "Suzuki GSX-R600 Red";
            transaction.totalPayment = suzukiGSX;
            break;
        case 5:
            transaction.motorBrand = "Yamaha Aerox Yellow";
            transaction.totalPayment = yamahaAerox;
            break;
        case 6:
            transaction.motorBrand = "Yamaha NMAX White";
            transaction.totalPayment = yamahaNMAX;
            break;
        case 7:
            transaction.motorBrand = "Honda Click Red";
            transaction.totalPayment = hondaClick;
            break;
        case 8:
            transaction.motorBrand = "Honda XR 150";
            transaction.totalPayment = hondaXR;
            break;
        case 9:
            transaction.motorBrand = "Bike Cycling";
            transaction.totalPayment = bike;
            break;
    }

    cout << "\tNo. of Days to rent: ";
    cin >> transaction.days;
    transaction.totalPayment *= transaction.days;

    enterInformation(transaction);
    rentalHistory.push_back(transaction);

system("CLS");

        cout<<"\t\tReceipt\n";
        cout<<endl;
        cout<<"\t\t__________________________________________________________________\n";
        cout<<endl;

        cout << "\t\tName: " << transaction.fullName << endl;
        cout << "\t\tMotor Brand: " << transaction.motorBrand << endl;
        cout << "\t\tDays: " << transaction.days << endl;
        cout << "\t\tTotal Payment: " << transaction.totalPayment << endl;
        cout << "\t\tTime Rented: " << asctime(localtime(&timetoday)) << endl;

    cout<<endl;
    cout<<"\t\t__________________________________________________________________\n";
    cout<<endl;

    cout << "Do you want to Rent another Motorcycle? (1 for Yes, 2 for No): ";
    int select;
    cin >> select;

    if (select == 1) {
       mainSelection();
    } else if (select == 2) {
        void exit(int Code);
    } else {
        cout << "Invalid Input, Please Try again." << endl;
        proceedRent();
    }
}






int main() {

termsAndConditions();

askwanotwo:

cout<<"Do you accept the Terms and Condition? [1] Agree  [2] Disagree  ";
int wanotwo;cin>>wanotwo;
    if(wanotwo == 1)
    {
        mainSelection();

    }
    else if(wanotwo == 2)
    {
        return 0;
    }
    else
    {
        cout<<"Invalid, Input Please Try Again\n";
        goto askwanotwo;
    }
    mainSelection();
    return 0;
}
